import { Redirect } from "expo-router"

export default function SexualActivityTab() {
  return <Redirect href="/sexual-activity" />
}

